package lab01;
//Bai 2
import javax.swing.JOptionPane;
public class FirstDialog {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello world, I am Hong Phuc!\n How are you?");
        System.exit(0);
    }
}



