package lab01;
//Bai 1
public class HelloWorld {
    public static void main (String[] args) {
        System.out.println("Xin chao\n cac ban! Minh la Hong Phuc");
        System.out.println("Hello\t world");
    }
}







